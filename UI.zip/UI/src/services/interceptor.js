import axios from 'axios'
import router from '../router'
import store from '../store'

const instance = axios.create();
instance.interceptors.request.use(function(config) {
    var token = sessionStorage.getItem('token_id');

    if (token != '' && token != null && token != undefined) {
        config.headers['authorization'] = 'Bearer ' + token;
    } else {
        router.push({ path: '/authentication/login' });
        return false;
    }

    config.headers['X-Requested-With'] = 'XMLHttpRequest';
    config.headers['Expires'] = '-1';
    config.headers['Cache-Control'] = "no-cache,no-store,must-revalidate,max-age=-1,private";

    // if (ie && config.method == 'get') {
    //   config.url = buildUrl(config.url, { timestamp: Date.now().toString() });
    // }
    // console.log('interceptor request');
    return config;

}, function(error) {
    return Promise.reject(error);
});

instance.interceptors.response.use(function(data) {
    return Promise.resolve(data);

}, function(error) {
    console.log(error);
    if (error.message == "Network Error" || error.response.status === 401) {
        store.commit('SET_ERROR', error.message == "Network Error" ? error.message : error.response.status);
        sessionStorage.removeItem('token_id');
        router.push({ path: '/authentication/login' }); // name: 'loginlayout', params: { error } });

    } else {
        console.log(error);
        return Promise.reject(error);
    }
});

export default instance;