export default {
    formatMoney(n, currency) {
        return currency + " " + n.replace(/./g, function(c, i, a) {
            return i > 0 && c !== "." && (a.length - i) % 3 === 0 ? "," + c : c;
        });
    },
    toPersianDigits(text) {
        var id = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
        return text.replace(/[0-9]/g, function(w) {
            return id[+w]
        });
    },
    hex2rgb(hex, opacity) {
        hex = (hex + '').trim()

        let rgb = null
        let match = hex.match(/^#?(([0-9a-zA-Z]{3}){1,3})$/)

        if (!match) {
            return null
        }

        rgb = {}

        hex = match[1]

        if (hex.length === 6) {
            rgb.r = parseInt(hex.substring(0, 2), 16)
            rgb.g = parseInt(hex.substring(2, 4), 16)
            rgb.b = parseInt(hex.substring(4, 6), 16)
        } else if (hex.length === 3) {
            rgb.r = parseInt(hex.substring(0, 1) + hex.substring(0, 1), 16)
            rgb.g = parseInt(hex.substring(1, 2) + hex.substring(1, 2), 16)
            rgb.b = parseInt(hex.substring(2, 3) + hex.substring(2, 3), 16)
        }

        rgb.css = 'rgb' + (opacity ? 'a' : '') + '('
        rgb.css += rgb.r + ',' + rgb.g + ',' + rgb.b
        rgb.css += (opacity ? ',' + opacity : '') + ')'

        return rgb
    },

    findInNestedByName(array, name) {
        if (typeof array !== 'undefined') {
            for (let i = 0; i < array.length; i++) {
                if (array[i].name === name) return [{...array[i] }]
                let a = this.findInNestedByName(array[i].children, name)
                if (a != null) {
                    a.unshift({...array[i] })
                    return [...a]
                }
            }
        }
        return null
    }
}