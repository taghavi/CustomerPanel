export default {
    getCurrentDate() {
        var dt = new Date();
        var currentDate = { year: '', month: '', day: '' };
        currentDate.month = dt.getMonth() + 1;
        currentDate.day = dt.getDate();
        currentDate.year = dt.getFullYear();
        return currentDate;
    },
    compareGregDates(date1, date2) {
        var d1 = new Date(...date1.split('/').map(parseFloat));
        var d2 = new Date(...date2.split('/').map(parseFloat));
        if (d2 >= d1)
            return true;
        else
            return false;
    },
    convertDBDate(value) {
        var tmpValue = value.split('T'); //.substring(0,value.indexOf('T'));         
        var shamsiDate = this.gregorian_to_jalali(...tmpValue[0].split('-').map(parseFloat));
        return shamsiDate.join('/') + ' ' + tmpValue[1].substring(0, (tmpValue[1].indexOf('.') > 0 ? tmpValue[1].indexOf('.') : tmpValue[1].length));
    },
    getGregDatefromCalendar(date) {
        var gregDate = this.jalali_to_gregorian(date.year, date.month, date.day);
        var month = gregDate[1].toString().length == 1 ? '0' + gregDate[1].toString() : gregDate[1];
        var day = gregDate[2].toString().length == 1 ? '0' + gregDate[2].toString() : gregDate[2];
        var resDate = gregDate[0] + '/' + month + '/' + day;
        return resDate;
    },
    gregorian_to_jalali(gy, gm, gd) {
        var g_d_m = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
        var jy, jm, jd, gy2, days;
        if (gy > 1600) {
            jy = 979;
            gy -= 1600;
        } else {
            jy = 0;
            gy -= 621;
        }
        gy2 = (gm > 2) ? (gy + 1) : gy;
        days = (365 * gy) + (parseInt((gy2 + 3) / 4)) - (parseInt((gy2 + 99) / 100)) + (parseInt((gy2 + 399) / 400)) - 80 + gd + g_d_m[gm - 1];
        jy += 33 * (parseInt(days / 12053));
        days %= 12053;
        jy += 4 * (parseInt(days / 1461));
        days %= 1461;
        if (days > 365) {
            jy += parseInt((days - 1) / 365);
            days = (days - 1) % 365;
        }
        jm = (days < 186) ? 1 + parseInt(days / 31) : 7 + parseInt((days - 186) / 30);
        jd = 1 + ((days < 186) ? (days % 31) : ((days - 186) % 30));
        return [jy, jm, jd];
    },
    jalali_to_gregorian(jy, jm, jd) {
        var gy, gm, gd, days, sal_a, v;
        if (jy > 979) {
            gy = 1600;
            jy -= 979;
        } else {
            gy = 621;
        }
        days = (365 * jy) + ((parseInt(jy / 33)) * 8) + (parseInt(((jy % 33) + 3) / 4)) + 78 + jd + ((jm < 7) ? (jm - 1) * 31 : ((jm - 7) * 30) + 186);
        gy += 400 * (parseInt(days / 146097));
        days %= 146097;
        if (days > 36524) {
            gy += 100 * (parseInt(--days / 36524));
            days %= 36524;
            if (days >= 365) days++;
        }
        gy += 4 * (parseInt(days / 1461));
        days %= 1461;
        if (days > 365) {
            gy += parseInt((days - 1) / 365);
            days = (days - 1) % 365;
        }
        gd = days + 1;
        sal_a = [0, 31, ((gy % 4 == 0 && gy % 100 != 0) || (gy % 400 == 0)) ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
        for (gm = 0; gm < 13; gm++) {
            v = sal_a[gm];
            if (gd <= v) break;
            gd -= v;
        }
        return [gy, gm, gd];
    }
}