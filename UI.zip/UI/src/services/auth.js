import axios from 'axios'

export default {
    login: function(user) {
        return axios.post('/token', "userName=" + encodeURIComponent(user.username) +
            "&password=" + encodeURIComponent(user.password) +
            "&grant_type=password").then((response) => {
            sessionStorage.setItem('token_id', response.data.access_token);
            sessionStorage.setItem('company_name', response.data.companyName);
            sessionStorage.setItem('credit', response.data.credit);
            Promise.resolve(response.data);

        }, (error) => {
            return Promise.reject(error);
        })
    },
    logOut() {
        sessionStorage.removeItem('token_id');
    },
}