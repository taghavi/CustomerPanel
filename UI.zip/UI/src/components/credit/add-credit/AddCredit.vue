<template>
<!-- <form method="post" action=" https://mabna.shaparak.ir:8080 "> 
  <fieldset> 
    <legend>Sendeing Data </legend> 
      <div>
          <label for="TerminalID">Terminal ID:</label>
          <input type="text" name="terminalID" value="93000005" /> 
      </div> 
          <div>
            <label for="Amount">Amount:</label> 
            <input type="text" name="amount" value="1000" /> 
          </div> 
          <div> 
            <label for="callbackURL">CallBackURL:</label> 
            <input type="text" name="callbackURL" value="http://localhost:64205/api/credit/managecallback" />
          </div>
          <div> 
            <label for="InvoiceID">Invoice ID:</label>  
            <input type="text" name="InvoiceID" value="123" /> 
          </div>   
          <div>   
            <label for="Payload">Payload :</label>
            <input type="text" name="Payload" value="" /> 
          </div>
          <div>  
            <label>&nbsp;</label> 
            <input type="submit" value="Send" class="submit" />
          </div>  
  </fieldset>
</form>  -->
<!-- eslint-disable -->
  <div class="form-elements">   
    <div class="row">
      <div class="col-md-12">
        <vuestic-widget :headerText="'menu.addCredit' | translate" v-bind:leftHeader="companyCredit">
            <div class="row">
              <div class="col-md-4">
                <fieldset>
                  <div class="form-group">
                    <div class="input-group">
                      <input required id="amount-input" name="amountInput" v-validate="{required:true, regex: /[1-9]+[0-9]*/}" v-model="params.amount"/>
                      <label class="control-label" for="amountInput">{{'forms.inputs.amount' | translate}}</label><i class="bar"></i>
                      <p class="text-danger" v-if="errors.has('amountInput')">{{ 'errors.required' | translate }}</p>
                    </div>
                  </div>
                  <vuestic-simple-select
                    :label="'forms.selects.PG' | translate"
                    v-model="PGSelect"
                    option-key="description"
                    v-bind:options="PGOptions">
                  </vuestic-simple-select>              
                  <p class="text-danger" v-if="errors.has('simple-select')">{{ 'errors.required' | translate }}</p>
                </fieldset>
                <div class="col-md-12">
                <circle-spinner class="circle-spinner" v-show="isLoading" :animation-duration="4000"  :size="80"  :color="palette.primary"/>
                  <div  class="d-flex flex-column flex-lg-row align-items-center justify-content-between down-container"> 
                    <input type="button" v-show="!isLoading" class="btn btn-primary btn-micro" v-bind:value="$t('buttons.payment')" @click="paymentProcess"/>      
                  </div>
                </div>
              </div>
              <div class="col-md-4">
              </div>
              <div class="col-md-4">
              </div>             
             </div>
          
        </vuestic-widget>
      </div>
    </div>
    <vuestic-modal :show.sync="show" ref="smallModal" v-bind:small="true" :cancelClass="'none'"
                   :okText="'modal.confirm' | translate" :cancelText="'modal.cancel' | translate">
      <div slot="title">{{'modal.paymentTitle' | translate}}</div>
      <div style="text-align: right;">
        {{paymentMessage}}
      </div>
    </vuestic-modal>
  </div>
</template>
<style lang="scss" scoped>
//          <form id="addCreditForm" name="addCreditName" v-on:submit.prevent="paymentProcess" novalidate>

.fileExtError {
  text-align: right;
  margin-bottom: 2%;
}
.contact-info {
  text-align: right;
  margin-right: 4%;
}
.contact-info h4 {
  margin-bottom: 1%;
  color: #4ae387;
}
.label-upload {
  margin-bottom: 0;
}
</style>


<script>
import SelectorOptions from "data/options/options"
import { mapGetters } from "vuex"
import transResult from "data/messages"
import * as _ from 'lodash'
import instance from 'services/interceptor'
import utils from 'services/utils'


export default {
  name: "add-credit",
  data() {
    return {
      balance : '',
      currentBalance: '0',
      isLoadingbalance: false,
      paymentMessage:'',
      show: true,
      pathToPayment: 'https://mabna.shaparak.ir:8080',
      isLoading: false,
      params: {
            //terminalID: "",
            amount: "",
           // callbackURL: "" ,
            terminalInfoId: "",
            payload:""
          },
      PGOptions: SelectorOptions.PGs,
      PGSelect: "" ,     
      toastText: "",
      toastIcon: "fa-star-o",
      toastPosition: "top-center",
      toastDuration: 4000,
      isToastFullWidth: false
    };
  },
  computed: {
    ...mapGetters(['palette',
                  'companyCredit'])
  },
  mounted() {
    var res= this.$route.query.transresult;
    if(res != null && res != undefined ){
      this.updateStatus(res);
      
    }
  },
  methods: {
    async updateStatus(res){
     this.isLoadingbalance = true;
     if(res == 0 ){
     var tt = await this.getBalance();
     }
     
     var transMsg= _.find(transResult.transResult,x => x.id == res);
     this.paymentMessage = transMsg.description;
     this.showSmallModal();
     
    },   
    getBalance() {
      instance.get('/api/credit/getcredit').then(
          response => {
            this.currentBalance = utils.toPersianDigits(response.data);         
            this.$store.commit('SET_CREDIT', this.currentBalance);
            this.isLoadingbalance = false;
            return Promise.resolve(response);
          },
          response => {
            this.isLoadingbalance = false;
            this.balance= "خطا!";
            return Promise.reject(response);
          }
        );
    },
     showSmallModal () {
        this.$refs.smallModal.open()
      },
    paymentProcess: function() {
     this.$validator.validateAll();
          if (this.errors.any()) {
           // console.log(this.errors);
            return false;
          }
         // console.log('readee');
      var method = "post";
      var path= this.pathToPayment;
      this.isLoading = true;
      this.params.terminalInfoId = this.PGSelect.id || 1;
      //console.log(this.PGSelect.id);
      // fetch('http://localhost:64205/api/credit/addcredit', {
      //   method: 'post',
      //   headers: {
      //     "Content-type": "application/json; charset=UTF-8"
      //   },
      //   body: this.params
      // })
      // .then(json)
      // .then(function (data) {
      //   console.log('Request succeeded with JSON response', data);
      // })
      // .catch(function (error) {
      //   console.log('Request failed', error);
      // });
      var hasBeenCalled = false;    
      instance.post('/api/credit/addcredit', this.params).then(
          response => {
             if (hasBeenCalled){
               debugger;              
               throw Error("Attempted to call callback twice")
          } 
          else
          {
          hasBeenCalled = true;
            //this.isLoading = false;
            method = method || "post"; // Set method to post by default if not specified.
            //console.log(params);
            // The rest of this code assumes you are not using a library.
            // It can be made less wordy if you use one.
            var form = document.createElement("form");
            form.setAttribute("method", method);
            form.setAttribute("action", path);
            form.setAttribute("id", "formforpay");
            form.setAttribute("name", "formforpayment");
            form.setAttribute("onsubmit", "return false;");
            form.setAttribute("v-on:submit.prevent", "submit")
            for(var key in response.data) {
              if(response.data.hasOwnProperty(key)) {
                  var hiddenField = document.createElement("input");
                  hiddenField.setAttribute("type", "hidden");
                  hiddenField.setAttribute("name", key);
                  hiddenField.setAttribute("value", response.data[key]);

                  form.appendChild(hiddenField);
              }
            }
            document.body.appendChild(form);
           form.submit();
          }          
          },
          response => {
            this.isLoading = false;
            if(response.response.data.message)
            this.paymentMessage = response.response.data.message;
            else
            this.paymentMessage = response;
            this.showSmallModal();

            // this.toastText = "خطا در انجام تراکنش";
            // this.toastIcon = "times-circle";
            // this.launchToast();
          }
        ).catch(error => {
            console.log('catch it');
            console.log(error);
        });
    },
    launchToast() {
      this.showToast(this.toastText, {
        icon: this.toastIcon,
        position: this.toastPosition,
        duration: this.toastDuration,
        fullWidth: this.isToastFullWidth
      });
    }
  }
};
</script>