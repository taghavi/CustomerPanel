<template>
  <div class="form-elements">   
    <div class="row">
      <div class="col-md-12">
        <vuestic-widget :headerText="'menu.creditReport' | translate">
          <form>
            <label class="text-danger" v-if="showConflictDateError">{{'errors.conflictDates' | translate}}</label><i class="bar"></i>
            <div class="row">
              <div class="col-md-4">
                <fieldset>                                       
                    <pdatepicker v-on:selected="dateSelectedEventFrom" id="pdatepicker" placeholder="از تاریخ" class="form-group" 
                    input-class="pdatepicker"></pdatepicker> 
                    <i class="fa fa-exclamation-triangle icon-right input-icon text-danger" v-if="!paramData.fromDate"></i>
                    <small v-if="!paramData.fromDate" class="help text-danger">{{'errors.emptyDatePicker' | translate}} </small>
                </fieldset>
              </div>
              <div class="col-md-4">                
                 <fieldset>
                    <pdatepicker v-on:selected="dateSelectedEventTo" id="pdatepicker" placeholder="تا تاریخ" class="form-group" 
                    input-class="pdatepicker"></pdatepicker> 
                    <i class="fa fa-exclamation-triangle icon-right input-icon text-danger" v-if="!paramData.toDate"></i>
                    <small v-if="!paramData.toDate" class="help text-danger">{{'errors.emptyDatePicker' | translate}} </small>
                </fieldset>                  
              </div>  
              <div class="col-md-4">                
                <div class="d-flex flex-column flex-lg-row align-items-center justify-content-between down-container"> 
                  <input readonly class="btn btn-primary btn-micro" v-bind:value="$t('buttons.search')" @click="getCreditHistory"/>                               
                </div>                         
              </div>          
            </div>            
          </form>
        </vuestic-widget>
      </div>
    </div>
    <div class="row">
        <div class="col-md-12">
          <vuestic-widget :headerText="$t('tables.searchResult')">
            <h1 v-if="showServerError">{{'errors.serverErrorMsg' | translate}}</h1>
            <circle-spinner class="circle-spinner" v-show="isLoading" :animation-duration="4000"  :size="80"  :color="palette.primary"/>
            <div id="tablewithpagination" class="table-responsive" v-show="!isLoading">
              <vuetable 
                  class="vuetable"
                  :apiMode="false" 
                  :data="tableData"            
                  :fields="tblfields"
                  :css="css.table"  />              
                <pagination v-show="showPagination" :chunk=50 class="pagination" :records="100" :per-page=2  @paginate="setPage">
                </pagination>     
            </div>         
          </vuestic-widget>            
        </div>
    </div>
  </div>
</template>

<style lang="scss">
@import "../../reports/reports.scss";

</style>

<script>
import {mapGetters} from 'vuex'
import Vuetable from 'vuetable-2/src/components/Vuetable'
import DataTableStyles from 'vuestic-components/vuestic-datatable/data/data-table-styles'
import dateConvertor from 'services/dateConvertor'
import instance from 'services/interceptor'


export default {
   name: 'credit-reports',
   components: {      
      Vuetable
    },
    computed: {
      ...mapGetters(['palette']),
    },
    data () {
      return {
        showPagination: false,
        showConflictDateError:false,
        showServerError: false,
        css: DataTableStyles,
        tableData: [],
        isLoading: false,
        tblfields: [
          {
            name: 'amount',
            title: 'مبلغ (ريال)',
            dataClass: 'text-center'
          },
          {
            name: 'dateCreated',
            title: 'تاریخ انجام',
            dataClass: 'text-center',
            callback: this.showShamsiDate
          },          
          {
            name: 'respCode',
            title: 'کد تراکنش',
            dataClass: 'text-center'
          },
        ],
        paramData:{
          fromDate:'',
          toDate:'',
          accountId:'5'
        },
      }
    },
    methods: {
      showShamsiDate(value){
       return dateConvertor.convertDBDate(value);
       },
      dateSelectedEventFrom(date){        
        this.paramData.fromDate= dateConvertor.getGregDatefromCalendar(date);              
        return this.paramData.fromDate;
      },
      dateSelectedEventTo(date){
        this.paramData.toDate= dateConvertor.getGregDatefromCalendar(date);       
        return this.paramData.toDate;
      },
      getCreditHistory(){
        if(this.paramData.fromDate && this.paramData.toDate){ 
         if(dateConvertor.compareGregDates(this.paramData.fromDate,this.paramData.toDate)){
          this.showConflictDateError=false;
          this.isLoading=true; 
          instance.post('/api/credit/creditHistory',this.paramData)
          .then(response => {   
            if(response!= null && response != "")
            this.showPagination = true;
            this.isLoading=false;
            this.tableData = response.data;
          }, response => {
            //console.log(response);
            this.isLoading=false;
            this.showServerError=true;
            this.showPagination = false;
          }); 
         }
         else
         {
           this.showConflictDateError=true;
         }
        }
    },
  }
}
</script>