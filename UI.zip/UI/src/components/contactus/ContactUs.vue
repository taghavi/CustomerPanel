<template>
<!-- eslint-disable -->
  <div class="form-elements">   
    <div class="row">
      <div class="col-md-12">
        <vuestic-widget :headerText="'menu.transactionReports' | translate">
          <form novalidate>
            <div class="row">
              <div class="col-md-4">
                <fieldset>
                  <div class="form-group">
                    <div class="input-group">
                      <input required id="subject-input" type="text" v-validate="{required:true}" name="subject" v-model="paramData.subject"/>
                      <label class="control-label" for="subject">{{'forms.inputs.subject' | translate}}</label><i class="bar"></i>
                      <p class="text-danger" v-if="errors.has('subject')">{{ 'errors.required' | translate }}</p>
                    </div>
                  </div>
                  <vuestic-simple-select
                    :label="'forms.selects.unit' | translate"
                    v-model="unitSelect"
                    option-key="description"
                    v-bind:options="unitOptions">
                  </vuestic-simple-select>
                  <vuestic-simple-select
                    :label="'forms.selects.priority' | translate"
                    v-model="prioritySelect"
                    option-key="description"
                    v-bind:options="priorityOptions">
                  </vuestic-simple-select>
                  <div class="form-group">
                    <div class="input-group">
                      <textarea type="text" id="simple-textarea" v-validate="{required:true}" name="msg-body" rows="4" v-model="paramData.message" required></textarea>
                      <label class="control-label" for="msg-body">{{'forms.inputs.message' | translate}}</label><i class="bar"></i>
                      <p class="text-danger" v-if="errors.has('msg-body')">{{ 'errors.required' | translate }}</p>
                    </div>
                  </div>
                  <div class="form-group form-group-w-btn">
                    <div class="input-group">
                      <input id="input-w-btn" v-model="fileName" required/>
                      <label class="control-label" for="input-w-btn">{{'forms.inputs.attachments' | translate}}</label><i class="bar"></i>
                    </div>
                    <input id="file-upload" type="file" name="file" @change="onFileChange"
                    accept=".gif,.jpg,.jpeg,.png,.doc,.docx, .xlsx, .pdf, .txt" style="display:none" />
                    <label for="file-upload" class="label-upload btn btn-micro btn-primary"  v-show="!isLoading">
                      {{'forms.inputs.chooseFile' | translate}}
                    </label>
                     <input readonly v-show="!isLoading" class="btn btn-primary btn-micro custom-btn-size"
                    style="margin-bottom:0px;"  v-bind:value="$t('buttons.delete')" @click="removeFile"/>    
                  </div>
                  <div class="form-group form-group-w-btn" v-if="fileUploadCount >= 2" id="fileUpload2">
                    <div class="input-group">
                      <input id="input-w-btn2" name="input-w-btn2" v-model="fileName2" required/>
                      <label class="control-label" for="input-w-btn2">{{'forms.inputs.attachments' | translate}}</label><i class="bar"></i>
                    </div>
                    <input id="file-upload2" type="file" name="file2" @change="onFileChange2"
                    accept=".gif,.jpg,.jpeg,.png,.doc,.docx, .xlsx, .pdf, .txt" style="display:none" />
                    <label for="file-upload2" class="label-upload btn btn-micro btn-primary"  v-show="!isLoading">
                      {{'forms.inputs.chooseFile' | translate}}
                    </label>
                   <input readonly v-show="!isLoading" class="btn btn-primary btn-micro custom-btn-size"
                    style="margin-bottom:0px;"  v-bind:value="$t('buttons.delete')" @click="removeFile2"/>      
                  </div>
                  <div class="form-group form-group-w-btn"  v-if="fileUploadCount >= 3" id="fileUpload3">
                    <div class="input-group">
                      <input id="input-w-btn3" name="input-w-btn3" v-model="fileName3" required/>
                      <label class="control-label" for="input-w-btn3">{{'forms.inputs.attachments' | translate}}</label><i class="bar"></i>
                    </div>
                    <input id="file-upload3" type="file" name="file3" @change="onFileChange3"
                    accept=".gif,.jpg,.jpeg,.png,.doc,.docx, .xlsx, .pdf, .txt" style="display:none" />
                    <label for="file-upload3" class="label-upload btn btn-micro btn-primary"  v-show="!isLoading">
                      {{'forms.inputs.chooseFile' | translate}}
                    </label>
                    <input readonly v-show="!isLoading" class="btn btn-primary btn-micro custom-btn-size"
                    style="margin-bottom:0px;"  v-bind:value="$t('buttons.delete')" @click="removeFile3"/>   
                  </div>
                  <div class="form-group form-group-w-btn" v-if="fileUploadCount >= 4" id="fileUpload4">
                    <div class="input-group">
                      <input id="input-w-btn4" v-model="fileName4" required/>
                      <label class="control-label" for="input-w-btn4">{{'forms.inputs.attachments' | translate}}</label><i class="bar"></i>
                    </div>
                    <input id="file-upload4" type="file" name="file4" @change="onFileChange4"
                    accept=".gif,.jpg,.jpeg,.png,.doc,.docx, .xlsx, .pdf, .txt" style="display:none" />
                    <label for="file-upload4" class="label-upload btn btn-micro btn-primary"  v-show="!isLoading">
                      {{'forms.inputs.chooseFile' | translate}}
                    </label>
                    <input readonly v-show="!isLoading" class="btn btn-primary btn-micro custom-btn-size"
                    style="margin-bottom:0px;"  v-bind:value="$t('buttons.delete')" @click="removeFile4"/>   
                  </div>
                  <div class="form-group form-group-w-btn" v-if="fileUploadCount === 5" id="fileUpload5">
                    <div class="input-group">
                      <input id="input-w-btn5" v-model="fileName5" required/>
                      <label class="control-label" for="input-w-btn5">{{'forms.inputs.attachments' | translate}}</label><i class="bar"></i>
                    </div>
                    <input readonly id="file-upload5" type="file" name="file5" @change="onFileChange5"
                    accept=".gif,.jpg,.jpeg,.png,.doc,.docx, .xlsx, .pdf, .txt" style="display:none" />
                    <label for="file-upload5" class="label-upload btn btn-micro btn-primary"  v-show="!isLoading">
                      {{'forms.inputs.chooseFile' | translate}}
                    </label>
                    <input readonly v-show="!isLoading" class="btn btn-primary btn-micro custom-btn-size"
                    style="margin-bottom:0px;"  v-bind:value="$t('buttons.delete')" @click="removeFile5"/>   
                  </div>
                  <div class="form-group">
                    <input readonly v-show="!isLoading" class="btn btn-primary btn-micro" v-bind:value="$t('forms.inputs.addFile')" @click="addFileUploader"/>      
                    <small v-if="exceedFileCounts" class="help text-danger">{{'errors.exceedFileCounts' | translate}} </small> 
                  </div>
                  <div class="fileExtError">
                    <i class="fa fa-exclamation-triangle icon-right input-icon text-danger"
                     v-if="wrongFile || wrongFile2 || wrongFile3 || wrongFile4 || wrongFile5"></i>
                    <small v-if="wrongFile || wrongFile2 || wrongFile3 || wrongFile4 || wrongFile5" 
                    class="help text-danger">{{'errors.allowedFileExtensions' | translate}} </small>                  
                  </div>
                  <div class="fileExtError">
                    <!-- <vue-recaptcha sitekey="6LfGYlcUAAAAAHnKirOkA5yyNWZ2mH94BIT0mLoX"></vue-recaptcha>                                        -->
                  </div>
                  <circle-spinner class="circle-spinner" v-show="isLoading" :animation-duration="4000"  :size="80"  :color="palette.primary"/>
                  <div  class="d-flex flex-column flex-lg-row align-items-center justify-content-between down-container">  
                    <input readonly v-show="!isLoading" class="btn btn-primary btn-micro custom-btn-size" v-bind:value="$t('buttons.send')" @click="sendMessage"/>      
                    <input readonly v-show="!isLoading" class="btn btn-primary btn-micro custom-btn-size" v-bind:value="$t('buttons.clear')" @click="resetForm"/>  
                  </div> 
                </fieldset>
              </div>
              <div class="col-md-8">
                <div class="contact-info">
                 <h4>{{ 'headings.contactInfo' | translate}}</h4> 
                 <hr>  
                  <address>
                    <strong>{{ 'company.addressTitle' | translate}}</strong><br>
                    {{ 'company.address' | translate}}<br>
                    <strong>{{ 'company.supportTitle' | translate}}</strong>
                    {{ 'company.support' | translate}}<br>
                    <strong>{{ 'company.telephoneTitle' | translate}}</strong>
                    {{ 'company.telephone' | translate}}<br>
                    <a href="mailto">info@mobtakerancell.ir</a>
                  </address>                 
                </div>
              </div>             
             </div>
          </form>
        </vuestic-widget>
      </div>
    </div>
  </div>
</template>
<style lang="scss" scoped>

.fileExtError{
  text-align: right;
  margin-bottom: 2%;
}
.contact-info{
  text-align: right;
  margin-right: 4%;
}
.contact-info h4{
  margin-bottom: 1%; 
  color: #4ae387; 
}
.label-upload{
  margin-bottom: 0;
}
</style>


<script>
import SelectorOptions from 'data/options/options'
import {mapGetters} from 'vuex'
import instance from 'services/interceptor'

export default {
    name: 'contact-us',
    data () {
        return {
          isLoading: false,
            paramData: {
                subject: '',
                unit: '',
                priority: '',
                message:''
            },
            unitOptions: SelectorOptions.unit,
            unitSelect: '',
            priorityOptions: SelectorOptions.priority,
            prioritySelect: '',
            file: '',
            fileName:'',
            file2: '',
            fileName2:'',
            file3: '',
            fileName3:'',
            file4: '',
            fileName4:'',
            file5: '',
            fileName5:'',
            wrongFile: false,
            wrongFile2: false,
            wrongFile3: false,
            wrongFile4: false,
            wrongFile5: false,
            toastText: '',
            toastIcon: 'fa-star-o',
            toastPosition: 'top-center',
            toastDuration: 4000,
            isToastFullWidth: false,
            fileUploadCount:1,
            exceedFileCounts: false
        }
    },
    computed: {
      ...mapGetters(['palette']),
    },
    methods: {
      removeFile(){
        this.file= '';
        this.fileName = '';
        this.wrongFile = false;
      },
      removeFile2(){
        this.file2 = '';
        this.fileName2 = '';
        this.wrongFile2 = false;
      },
      removeFile3(){
        this.file3 = '';
        this.fileName3 = '';
        this.wrongFile3 = false;
      },
      removeFile4(){
        this.file4 = '';
        this.fileName4 = '';
        this.wrongFile4 = false;
      },
      removeFile5(){
        this.file5 = '';
        this.fileName5 = '';
        this.wrongFile5 = false;
      },
      resetForm(){        
        this.paramData.subject = '';
        this.paramData.message = '';
        this.unitSelect = '';
        this.prioritySelect = '';
        this.removeFile();
        this.removeFile2();
        this.removeFile3();
        this.removeFile4();
        this.removeFile5();
      },
      addFileUploader() {
        if(this.fileUploadCount >= 5)
        {
          this.exceedFileCounts = true;
          return;
        }
        else
          this.fileUploadCount++;
      },
      launchToast () {
        this.showToast(this.toastText, {
          icon: this.toastIcon,
          position: this.toastPosition,
          duration: this.toastDuration,
          fullWidth: this.isToastFullWidth
        })
      },
         onFileChange(e) {
            this.file = e.target.files[0] || e.dataTransfer.files[0];
            this.fileName = this.file.name;
            const allowedFileExts = ['gif','jpg','jpeg','png','doc','docx', 'xlsx', 'pdf', 'txt'];
            if(allowedFileExts.indexOf(this.fileName.split('.').pop())<0)
              this.wrongFile=true;
              else
              this.wrongFile=false;
            if (!this.file.length)
                return;
         },
          onFileChange2(e) {
            this.file2 = e.target.files[0] || e.dataTransfer.files[0];
            this.fileName2 = this.file2.name;
            const allowedFileExts = ['gif','jpg','jpeg','png','doc','docx', 'xlsx', 'pdf', 'txt'];
            if(allowedFileExts.indexOf(this.fileName2.split('.').pop())<0)
              this.wrongFile2=true;
              else
              this.wrongFile2=false;
            if (!this.file2.length)
                return;
         },
         onFileChange3(e) {
            this.file3 = e.target.files[0] || e.dataTransfer.files[0];
            this.fileName3 = this.file3.name;
            const allowedFileExts = ['gif','jpg','jpeg','png','doc','docx', 'xlsx', 'pdf', 'txt'];
            if(allowedFileExts.indexOf(this.fileName3.split('.').pop())<0)
              this.wrongFile3=true;
              else
              this.wrongFile3=false;
            if (!this.file3.length)
                return;
         },
         onFileChange4(e) {
            this.file4 = e.target.files[0] || e.dataTransfer.files[0];
            this.fileName4 = this.file4.name;
            const allowedFileExts = ['gif','jpg','jpeg','png','doc','docx', 'xlsx', 'pdf', 'txt'];
            if(allowedFileExts.indexOf(this.fileName4.split('.').pop())<0)
              this.wrongFile4=true;
              else
              this.wrongFile4=false;
            if (!this.file4.length)
                return;
         },
         onFileChange5(e) {
            this.file5 = e.target.files[0] || e.dataTransfer.files[0];
            this.fileName5 = this.file5.name;
            const allowedFileExts = ['gif','jpg','jpeg','png','doc','docx', 'xlsx', 'pdf', 'txt'];
            if(allowedFileExts.indexOf(this.fileName5.split('.').pop())<0)
              this.wrongFile5=true;
              else
              this.wrongFile5=false;
            if (!this.file5.length)
                return;
         },
        sendMessage(){
          if(this.wrongFile || this.wrongFile2 || this.wrongFile3 || this.wrongFile4 || this.wrongFile5)
            return;

          
          this.$validator.validateAll();
          if (this.errors.any()) {
            console.log(this.errors);
            return false;
          }
          this.isLoading=true;
          var formdata = new FormData();
          
          this.paramData.unit=this.unitSelect.description;
          this.paramData.priority=this.prioritySelect.description;
          formdata.append('param', JSON.stringify(this.paramData));
          if(this.fileName!= null && this.fileName !='')
            formdata.append('userpic', this.file);
          if(this.fileName2!= null && this.fileName2 !='')
            formdata.append('userpic2', this.file2);
          if(this.fileName3!= null && this.fileName3 !='')
            formdata.append('userpic3', this.file3);
          if(this.fileName4!= null && this.fileName4 !='')
            formdata.append('userpic4', this.file4);
          if(this.fileName5!= null && this.fileName5 !='')
            formdata.append('userpic5', this.file5);
          
          this.getTransactions(formdata);
        },
        getTransactions(medata){ 
          instance.post('/api/contactus/sendmessage',medata)
          .then(response => {   
            this.isLoading=false;  
            this.toastText= 'با موفقیت ارسال شد.';
            this.toastIcon= 'check-circle';
            this.launchToast();
            this.resetForm();
          }, response => {
            this.isLoading=false;
            this.showServerError=true;
            this.toastText= 'خطا در ارسال پیام';
            this.toastIcon= 'times-circle';
            this.launchToast();
        }); 
      },
    }

}
</script>