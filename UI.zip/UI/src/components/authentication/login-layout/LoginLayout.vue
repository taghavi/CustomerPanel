<template>
  <div class="login">
    <h2>{{'auth.welcome' | translate}}</h2>
    <form name="login" ref="loginForm"  v-on:keyup.enter="login">
      <div class="form-group">
        <div class="input-group">
          <input type="text" id="email" required="required" v-model="user.username"/>
          <label class="control-label" for="email">{{'auth.userName' | translate}}</label><i class="bar"></i>
        </div>
      </div>
      <div class="form-group">
        <div class="input-group">
          <input type="password" id="password" required="required" v-model="user.password"/>
          <label class="control-label" for="password">{{'auth.password' | translate}}</label><i class="bar"></i>
        </div>
      </div>
      <i class="fa fa-exclamation-triangle icon-right input-icon text-danger" v-if="errorMsg"></i>
      <small v-if="errorMsg" class="help text-danger">{{ errorMsg }} </small>
      <div class="d-flex flex-column flex-lg-row align-items-center justify-content-between down-container">
        <circle-spinner class="circle-spinner" v-show="isLoading" :animation-duration="4000"  :size="80"  :color="palette.primary"/>
        <!-- <button v-show="!isLoading" class="btn btn-primary" @click="login">
          {{'auth.login' | translate}}
        </button> -->
        <input v-show="!isLoading" class="btn btn-primary btn-micro" type="button"  v-bind:value="$t('auth.login')" @click="login"/>   
        <!-- <input  class="btn btn-primary btn-micro" type="submit" value="test" @click="sub"/>       -->
   
        <!-- <router-link class='link' :to="{name: 'Signup'}">{{'auth.createAccount' | translate}}</router-link> -->
      </div>
    </form>
  </div>
</template>

<script>
import auth from 'services/auth'
import {mapGetters} from 'vuex'

  export default {
    name: 'login-layout',
    data() {
        return {
          isLoading: false,
          errorMsg: '',
          user :{
            username: '', 
            password: ''
            },
        }
    },
    computed: {
      ...mapGetters(['palette',
                     'hasLoginError'
                    ]),
    },
    mounted(){
      if(this.hasLoginError != '' && this.hasLoginError != null && this.hasLoginError != undefined){
        this.showError(this.hasLoginError);
        this.$store.commit('EMPTY_ERROR');
      }
    },
    methods: {  
      showError(er){
      if(this.hasLoginError != '' && this.hasLoginError != null && this.hasLoginError != undefined){
        if(er === "Network Error")
            this.errorMsg="عدم ارتباط با سرور"
          else if(er==401)
            this.errorMsg = "لطفا مجددا وارد شوید."
      }
      else
      {
        if(er.message === "Network Error")
            this.errorMsg="عدم ارتباط با سرور"
          else if(er.response.status===400)
            this.errorMsg = "نام کاربری یا رمز عبور اشتباه است."
          else if(er.response.status===401)
            this.errorMsg = "لطفا مجددا وارد شوید."
      }
      },   
      login(){ 
        if(this.user.username.length > 0 && this.user.password.length > 0){       
          this.isLoading = true;
          auth.login(this.user).then((res)=>
          {    
            this.$store.commit('SET_NAME');
            this.$store.commit('SET_CREDIT');
            this.$router.push('/');
            this.isLoading = false;
          },(er) =>
          {      
            this.isLoading = false;
            this.showError(er);
            auth.logOut();          
            this.$router.push({ path: '/authentication/login' });
          })
        }
        else
        {
           this.errorMsg = "نام کاربری و رمز عبور را پر کنید."
        }
      }
    }
  }
</script>

<style lang="scss">
  @import '../../../sass/variables';
  @import '~bootstrap/scss/mixins/breakpoints';
  @import "~bootstrap/scss/functions";
  @import '~bootstrap/scss/variables';

  input:-webkit-autofill,
  input:-webkit-autofill:hover, 
  input:-webkit-autofill:focus
  input:-webkit-autofill, 
  textarea:-webkit-autofill,
  textarea:-webkit-autofill:hover
  textarea:-webkit-autofill:focus,
  select:-webkit-autofill,
  select:-webkit-autofill:hover,
  select:-webkit-autofill:focus {
    // border: 1px solid green;
    // -webkit-text-fill-color: green;
    // -webkit-box-shadow: 0 0 0px 1000px #000 inset;
    //transition: background-color all 5000s ease;
    + .control-label {
        font-size: 0.6rem;
      color: #4ae387;
      font-weight: 600;
      text-transform: uppercase;
      top: -0.6rem;
      right: 0;
    }
    
  }
  .login {
    @include media-breakpoint-down(md) {
      width: 100%;
      padding-right: 2rem;
      padding-left: 2rem;
      .down-container {
        .link {
          margin-top: 2rem;
        }
      }
    }

    h2 {
      text-align: center;
    }
    width: 21.375rem;

    .down-container {
      margin-top: 3.125rem;
    }
  }
</style>
