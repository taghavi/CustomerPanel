<template>
<!-- eslint-disable -->
  <div class="form-elements">   
    <div class="row">
      <div class="col-md-12">
        <vuestic-widget :headerText="'menu.transactionReports' | translate">
          <form novalidate>
            <div class="row">
              <div class="col-md-4">
                <fieldset>                                       
                    <pdatepicker name="pdatepickerInput" v-on:selected="dateSelectedEvent"
                    id="pdatepicker" placeholder="انتخاب تاریخ" class="form-group" input-class="pdatepicker"> 
                    </pdatepicker> 
                      <!-- <i class="fa fa-exclamation-triangle icon-right input-icon text-danger" v-if="!paramData.transactionDate"></i>
                      <small v-if="!paramData.transactionDate" class="help text-danger">{{'errors.emptyDatePicker' | translate}} </small> -->
                  <div class="form-group">
                    <div class="input-group">
                      <input required id="phonNumber-input" v-model="paramData.phoneNumber"/>
                      <label class="control-label" for="phonNumber-input">{{'forms.inputs.phoneNumber' | translate}}</label><i class="bar"></i>
                    </div>
                  </div>
                   <div class="form-group">
                    <div class="input-group">
                      <input required id="cusTransId-input" v-model="paramData.customerTransactionId"/>
                      <label class="control-label" for="cusTransId-input">{{'forms.inputs.customerTransactionId' | translate}}</label><i class="bar"></i>
                    </div>
                  </div>
                  <vuestic-simple-select
                    :label="'forms.selects.transactionType' | translate"
                    v-model="transactionTypeSelect"
                    option-key="description"
                    v-bind:options="transactionTypeOptions">
                  </vuestic-simple-select>
                   <!-- <div class="form-group">
                    <div class="input-group">
                      <input id="customer-input" v-model="paramData.customerName"/>
                      <label class="control-label" for="customer-input">{{'forms.inputs.customer' | translate}}</label><i class="bar"></i>
                    </div>
                  </div> -->
                </fieldset>
              </div>
              <div class="col-md-4">                
                 <fieldset>                  
                  <vuestic-simple-select
                    :label="'forms.selects.transactionStatus' | translate"
                    v-model="transactionStatusSelect"
                    option-key="description"
                    v-bind:options="transactionStatusOptions">
                  </vuestic-simple-select>
                   <vuestic-simple-select
                    :label="'forms.selects.mobileCellOperator' | translate"
                    v-model="mobileCellOperatorSelect"
                    option-key="description"
                    v-bind:options="mobileCellOperatorOptions">
                  </vuestic-simple-select>
                  <div class="form-group">
                    <div class="input-group">
                      <input required id="sysTransId-input" v-model="paramData.systemTransactionId"/>
                      <label class="control-label" for="sysTransId-input">{{'forms.inputs.systemTransactionId' | translate}}</label><i class="bar"></i>
                    </div>
                  </div>
                </fieldset>                  
              </div>  
              <div class="col-md-4">
                <div class="d-flex flex-column flex-lg-row align-items-center justify-content-between down-container">  
                  <input readonly class="btn btn-primary btn-micro " type="button" v-bind:value="$t('buttons.search')" @click="getTransactionsbtn"/>  
                  <input readonly class="btn btn-primary btn-micro " type="button" v-bind:value="$t('buttons.clear')" @click="resetForm"/>  
                </div>  
                <div class="d-flex flex-column flex-lg-row align-items-center justify-content-between down-container"> 
                  <input readonly class="btn btn-primary btn-micro" type="button" v-bind:value="$t('buttons.exportExcel')" @click="getExcel"/>  
                </div>   
              </div>          
            </div>
          </form>
        </vuestic-widget>
      </div>
    </div>
    <div class="row">
        <div class="col-md-12">
          <vuestic-widget :headerText="$t('tables.searchResult')">
            <h1 v-if="showServerError">{{'errors.serverErrorMsg' | translate}}</h1>
            <circle-spinner class="circle-spinner" v-show="isLoading" :animation-duration="4000"  :size="80"  :color="palette.primary"/>
            <div id="tablewithpagination" class="table-responsive" v-show="!isLoading">
              <vuetable 
                  class="vuetable"
                  :apiMode="false" 
                  :data="tableData"            
                  :fields="mytblfields"
                  :itemsPerPage="itemsPerPage"
                  :defaultPerPage="defaultTablePerPage"
                  :css="css.table"  />              
                
              <div class="d-flex justify-content-center mb-4">
                <div class="custom-btn-group" style="">
                <a class="btn-nav btn btn-primary" @click="paginate(1)" :class="{'disabled': (currentPage == 1)}"><i class="fa fa-angle-double-right"></i></a>
                <a class="btn-nav btn btn-primary pagination-link-btn" @click="pageBackward" :class="{'disabled': (currentPage == 1)}"><i class="fa fa-angle-right"></i></a>
                <a class="btn btn-primary hide-not-focused-btn" @click="paginate(n)" v-for="n in pageNums" :key="n" 
                  :class="{'focus': isOnCurrentPage(n), 'disabled': isGreaterthanLastPage(n)}">{{n}}</a>
                <a class="btn-nav btn btn-primary pagination-link-btn" @click="pageForward" :class="{'disabled': isOnLastPage}">
                  <i class="fa fa-angle-left"></i>
                </a>
                <!-- <a class="btn-nav btn btn-primary pagination-link-btn" :class="{'disabled': isOnLastPage}"><i class="fa fa-angle-double-left"></i></a> -->
                </div>
              </div>   
            </div>   
          </vuestic-widget>            
        </div>
    </div>
  </div>
</template>

<style lang="scss">
@import "../reports.scss";
h1 {
  text-align: center;
}
.custom-btn-size {
  width: 100%;
}
//---------------style for pagination---------------------------
.custom-btn-group {
  color: #fff;
  box-shadow: 0 4px 9.6px 0.4px rgba(74,227,135,.5);
  border-radius: 1.875rem;
  position: relative;
  display: -webkit-inline-box;
  display: -ms-inline-flexbox;
  display: inline-flex;
  vertical-align: middle;

    .btn:not(:last-child)   {
      border-top-left-radius: 0;
      border-bottom-left-radius: 0; 
    }
    .btn:not(:first-child)   {
      border-top-right-radius: 0;
      border-bottom-right-radius: 0; 
    }
    .btn {
    padding-left: 1.53rem;
    padding-right: 1.53rem;
    box-shadow: none;
    margin: 0px;
    }
    
}
 
</style>

<script>
import ItemsPerPageDef from 'vuestic-components/vuestic-datatable/data/items-per-page-definition'
import SelectorOptions from 'data/options/options'
import {mapGetters} from 'vuex'
import Vuetable from 'vuetable-2/src/components/Vuetable'
import DataTableStyles from 'vuestic-components/vuestic-datatable/data/data-table-styles'
import dateConvertor from 'services/dateConvertor'
import utils from 'services/utils'
import instance from '../../../services/interceptor';


export default {
   name: 'transaction-reports',
   components: {      
      Vuetable
    },
    data () {
      return {
        lastPage:'',
        pageNums: [1,2,3],
        isOnLastPage: false,
        showPagination: false,
        showServerError:false,
        css: DataTableStyles,
        isLoading: false,      
        itemsPerPage: ItemsPerPageDef.itemsPerPage,
        defaultTablePerPage:3,
        tableData:[],
        mytblfields: [
            {
              name: 'operatorTitle',
              title: 'اپراتور',
              dataClass: 'text-center'
            },
            {
              name: 'prcode',
              title: 'نوع تراکنش',
              dataClass: 'text-center',
              sortField: 'title',
              callback: this.getPrCodeTitle
            },
            {
              name: 'originalAmount',
              title: 'مبلغ شارژ',
              dataClass: 'text-center',
              callback: this.getProperPrice
            },
            {
              name: 'txStatus',
              title: 'وضعیت تراکنش',
              dataClass: 'text-center',
              callback: this.getTransactionStatusTitle
            },
            {
              name: 'addData1',
              title: 'شماره همراه',
              callback: this.removePINphonNumbers
            },
            {
              name: 'createdOn',
              title: 'تاریخ درخواست',
              dataClass: 'text-center',
              callback: this.showShamsiDate
            },
            {
              name: 'modifiedOn',
              title: 'تاریخ انجام',
              dataClass: 'text-center',
              callback: this.showShamsiDate
            },
            {
              name: 'reserveNumber_RequestSerial',
              title: 'کد پیگیری مشتری',
              dataClass: 'text-center'
            },
            {
              name: 'localSerial',
              title: 'کد پیگیری سامانه',
              dataClass: 'text-center'
            },
            {
              name: 'customerResMsg',
              title: 'متن پاسخ',
              //callback:this.getfirstline
            }
            
          ],      
        users:'', 
        paramData:{
              transactionDate:null,
              phoneNumber:'',
              customerTransactionId:'',
              customerName:"",
              transactionType:'',
              transactionStatus:'',
              mobileCellOperator:'',
              systemTransactionId:'',
              pageIndex:1,
              pageSize:10
              },
        transactionTypeOptions: SelectorOptions.transactionTypes,
        transactionTypeSelect: '',
        transactionStatusOptions: SelectorOptions.transactionStatus,
        transactionStatusSelect: '',
        mobileCellOperatorOptions: SelectorOptions.mobileCellOperators,
        mobileCellOperatorSelect: '',
        currentPage: 1,
      }
    },
    computed: {
      ...mapGetters(['palette']),
     
    },
     methods: {
      getExcel() {
      this.isLoading=true;      
      this.paramData.pageIndex= this.currentPage;
      this.paramData.transactionStatus= this.transactionStatusSelect.id != -1? this.transactionStatusSelect.id: '' ;
      this.paramData.transactionType=this.transactionTypeSelect.id != -1? this.transactionTypeSelect.id:'' ;
      this.paramData.mobileCellOperator=this.mobileCellOperatorSelect.id != -1? this.mobileCellOperatorSelect.id: '';
      instance.post('/api/report/exceltransreport',this.paramData)
       .then(response => { 
         console.log(response.data);
          const url = window.URL.createObjectURL(new Blob([response.data], {type: 'application/vnd.ms-excel'}));          
          const filename = (response.headers['content-disposition'] || '').split('filename=')[1];                  
          const result = document.createElement('a');
          result.href = url;
          result.setAttribute('download', filename);
          document.body.appendChild(result);
          result.click();
          this.isLoading=false;
          }, response => {
            this.isLoading=false;
            this.showServerError=true;
          }); 
      },
       isGreaterthanLastPage(page){
         if(this.lastPage != '')
         return (page > this.lastPage)
         else
         return false;
       },
       pageForward(){
         if(this.currentPage == this.pageNums[2] ){
           this.pageNums = this.pageNums.map(x => x + 3);
         }
         this.currentPage++;
         this.getTransactions();
       },
       pageBackward(){
         if(this.currentPage == this.pageNums[0] && this.currentPage != 1 ){
           this.pageNums = this.pageNums.map(x => x - 3);
         }
         this.currentPage--;
         this.getTransactions();
       },
       paginate(page){
         if(page == 1)
          this.pageNums = [1,2,3];
         this.currentPage= page;
         this.getTransactions();
       },
        isOnCurrentPage(n) {
        return this.currentPage == n;
      },
       getProperPrice(value) {
         return utils.formatMoney(value.toString(), "");
       },
       resetForm(){
        this.transactionTypeSelect= '';
        this.transactionStatusSelect= '';
        this.mobileCellOperatorSelect= '';
        this.currentPage= 1;
        this.paramData.phoneNumber= '';
        this.paramData.customerTransactionId= '';
        this.paramData.transactionDate= '';
        document.querySelector("input[name=pdatepickerInput]").value = '';
      },
       isEmpty(value){
         if(value ===undefined)
          return true;
         if(value.length>0)
          return false;
         else
          return true;
       },
       removePINphonNumbers(value) {
         if(value.length<10){
          return '';
          }
          else
          return value;
       },
       getTransactionStatusTitle(value){
         var title="";
         switch(value){
           case 0:
            title="ناموفق";
            break;
           case 1:
            title="موفق";
            break;
           case 2:
            title="ناموفق، بازگشت داده شده";
            break;
           case 3:
            title="ناموفق، در حال بازگشت";
            break; 
           case 4:
            title="در انتظار شارژ";
            break;
           case 5:
            title="رزرو";
            break;            
           default:
            title="سایر"
         }
          return title;
       },
       getPrCodeTitle(value){
         //for now we just hard code it but then we can use _slot in vuetable to access operatorid to have them all in order
         switch(value) {
            case 0:
            case 1:
            case 8:
            case 80:
            case 6:
                return "شارژ مستقیم"
                break;
            case 84:
                return "شارژ دلخواه"
                break;
            case 81:
                return "شارژ مستقیم فوق العاده"
                break;
            case 82:
                return "شارژ مستقیم جوانان"
                break;
            case 83:
                return "شارژ مستقیم بانوان"
                break;
            case 5:
            case 51:
                return "پین"
                break;
            case 13:
            case 14:
            case 15:
            case 16:
            case 17:
            case 18:
            case 19:
            case 20:
                return "اینترنت"
                break;
            case 11:
                return "قبض"
                break;
            default:
                return "سایر"
        }
       },
       getfirstline(value){
         return value.substring(0,value.indexOf('.'));
       },
       showShamsiDate(value){
         console.log(value);
         console.log(dateConvertor.convertDBDate(value));
        return dateConvertor.convertDBDate(value);
       },
      
    //     transform: function(responsedata) {
    //       var transformed = {};
    //       transformed.pagination = {
    //       total: 200,
    //       per_page: 10,
    //       current_page: this.current_page,
    //       last_page: 10,
    //       next_page_url: null,
    //       prev_page_url: null,
    //       from: 1,
    //       to: 10        
    //   }          
    //   transformed.data=responsedata;
    //   return transformed
    // },
    dateSelectedEvent(date){
      this.paramData.transactionDate= dateConvertor.getGregDatefromCalendar(date);       
      return this.paramData.transactionDate;
    },
    getTransactionsbtn() {
      this.currentPage = 1;
      this.pageNums = [1,2,3];
      this.getTransactions();

    },
    getTransactions(){
      this.isLoading=true;      
      this.paramData.pageIndex= this.currentPage;
      this.paramData.transactionStatus= this.transactionStatusSelect.id != -1? this.transactionStatusSelect.id: '' ;
      this.paramData.transactionType=this.transactionTypeSelect.id != -1? this.transactionTypeSelect.id:'' ;
      this.paramData.mobileCellOperator=this.mobileCellOperatorSelect.id != -1? this.mobileCellOperatorSelect.id: '';
      instance.post('/api/report/queryrepcheck',this.paramData)
       .then(response => {   
         if(response.data.length < 10){
           this.isOnLastPage = true;
           this.lastPage = this.currentPage;
         }
         else
         {
           this.isOnLastPage = false;
           this.lastPage = '';
         }
         this.showServerError=false;
         this.isLoading=false;
         this.tableData =response;
       }, response => {
         this.isLoading=false;
         this.showPagination = false;
         this.showServerError=true;
         this.tableData ='';
       }); 
    },   
  }
}
</script>
