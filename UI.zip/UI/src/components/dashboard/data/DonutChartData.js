import store from 'vuex-store'

let palette = store.getters.palette

export default {
  labels: ['درخواست ناموفق', 'درخواست موفق'],
  datasets: [{
    label: 'درخواست‌ها (تعداد)',
    backgroundColor: [palette.danger, palette.info],
    data: []
  }]
}
