<template>
  <div class="dashboard">
    <vuestic-widget class="no-padding no-v-padding" :headerText="'menu.dashboard' | translate">
      <div class="row">
        <div class="col-md-6">
          <div class="row">
          <div class="col-md-1" style="padding-top:2%;">
            <span aria-hidden="true" class="fa fa-calendar" style="font-size: 30px;display: inline;"></span>
            <!-- <small style="font-size: 16px;">{{'labels.chooseDate' | translate}}</small> -->
          </div>
          <pdatepicker id="pdatepicker" v-on:selected="dateSelectedEventFrom" v-model="curdate" placeholder="انتخاب تاریخ" class="form-group col-md-9" 
                    input-class="pdatepicker"></pdatepicker> 
          </div>
          <div class="row">
            <div class="col-md-1"></div>
            <div class="d-flex flex-column flex-lg-row align-items-center justify-content-between down-container" style="margin-bottom:2%;"> 
              <input readonly class="btn btn-primary btn-micro" v-bind:value="$t('buttons.search')" @click="getData"/>  
            </div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <vuestic-widget class="chart-widget" :headerText="'charts.generalStatus' | translate">
            <circle-spinner class="circle-spinner" v-if="isLoading" :animation-duration="4000"  :size="80"  :color="palette.primary"/>
            <span  v-else-if="serverError">{{'errors.serverErrorMsg' | translate}}</span>
            <vuestic-chart v-else v-bind:data="donutChartData" type="donut"></vuestic-chart>
          </vuestic-widget>
        </div>      
        <div class="col-md-6">
          <vuestic-widget class="chart-widget" :headerText="'charts.dailyStatistic' | translate">
            <circle-spinner class="circle-spinner" v-if="isLoading" :animation-duration="4000"  :size="80"  :color="palette.primary"/>
            <span  v-else-if="serverError">{{'errors.serverErrorMsg' | translate}}</span>
            <vuestic-chart v-else v-bind:data="verticalBarChartData" type="vertical-bar"></vuestic-chart>
          </vuestic-widget>
        </div>
      </div>
    </vuestic-widget>    
  </div>
</template>

<style lang="scss">
@import "../reports/reports.scss";

</style>

<script>
  import DonutChartData from './data/DonutChartData'
  import VerticalBarChartData from './data/VerticalBarChartData'
  import {mapGetters} from 'vuex'
  import dateConvertor from 'services/dateConvertor'
  import utils from 'services/utils'
  import instance from 'services/interceptor'

  export default {
    name: 'dashboard',
    data(){
      return{
            curdate: this.currentDate(),
            verticalBarChartData: VerticalBarChartData,
            donutChartData: DonutChartData,
            isLoading: false,
            paramData: {
              date: ''
            },
            serverError: false
      }
    },
    mounted() {
     this.getData();
    },
    computed: {
      
      ...mapGetters(['palette']),
    },
    methods: {
       currentDate(){
        var curDate = dateConvertor.getCurrentDate();       
        var shamsi = dateConvertor.gregorian_to_jalali(curDate.year, curDate.month, curDate.day);  
        return shamsi.join('/');
      },
      getData(){
        this.isLoading=true;
      //donut chart data fill
       instance.post('/api/dashboard/getdashboarddata',this.paramData)
          .then(response => {
            this.isLoading=false;
            if (response.data === undefined || response.data.length == 0) {  
              var donutDataEmpty=[];
              this.donutChartData.datasets[0].data= [];
              var verticalBarDataEmpty=[];
              this.verticalBarChartData.datasets[0].data= [];
              this.verticalBarChartData.datasets[1].data= [];
              this.verticalBarChartData.datasets[2].data= [];
            }
            else
            {
            var failedCount=response.data[0].failedCount;
            var totalRequest=response.data[0].totalRequest;
            var successCount=totalRequest-failedCount;
            var arr=[];
            arr.push(failedCount);
            arr.push(successCount);
            
            this.donutChartData.datasets[0].data= arr;
          
            var billCount= response.data[0].billCount;
            var pinChargeCount= response.data[0].pinChargeCount;
            var topUpCount= response.data[0].topUpCount;   
            this.verticalBarChartData.labels[0] = 'تاریخ' + utils.toPersianDigits(this.curdate)  ;
            this.verticalBarChartData.datasets[0].data[0]= billCount;
            this.verticalBarChartData.datasets[1].data[0]= topUpCount;
            this.verticalBarChartData.datasets[2].data[0]= pinChargeCount;
            }
          }, response => {
            this.isLoading=false;
            this.serverError=true;
            
          });  
      },
      dateSelectedEventFrom(date){
        this.paramData.date= dateConvertor.getGregDatefromCalendar(date);       
       
      }
    }
  }  
</script>