// Polyfills
import 'es6-promise/auto'
import 'babel-polyfill'

// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import VeeValidate from 'vee-validate'
import App from './App'
import store from './store'
import router from './router'
import { sync } from 'vuex-router-sync'
import VuesticPlugin from 'vuestic-theme/vuestic-plugin'
import './i18n'
import PDatePicker from 'vue2-persian-datepicker'
import { Pagination } from 'vue-pagination-2'
import { FulfillingBouncingCircleSpinner } from 'epic-spinners'
//import VueRecaptcha from 'vue-recaptcha'
import VueAuthenticate from 'vue-authenticate'
import VueAxios from 'vue-axios'
import axios from 'axios'

axios.defaults.baseURL = 'http://192.168.5.2:5001'; //'http://localhost:64205'; //
Vue.prototype.$companyName = 'default';
Vue.prototype.$companycredit = '0';

Vue.use(VueAxios, axios);
// Vue.use(VueAuthenticate, {
//     baseUrl: 'http://localhost:64205', // Your API domain
//     loginUrl: '/token',
//     // providers: {
//     //     github: {
//     //         clientId: '',
//     //         redirectUri: '' // Your client app URL
//     //     }
//     // }
// })

//Vue.component('vue-recaptcha', VueRecaptcha);

Vue.component('circle-spinner', FulfillingBouncingCircleSpinner);

Vue.component('pagination', Pagination);

Vue.component('pdatepicker', PDatePicker)

Vue.use(VuesticPlugin)

// NOTE: workaround for VeeValidate + vuetable-2
Vue.use(VeeValidate, { fieldsBagName: 'formFields' })

sync(store, router)

let mediaHandler = () => {
    if (window.matchMedia(store.getters.config.windowMatchSizeLg).matches) {
        store.dispatch('toggleSidebar', true)
    } else {
        store.dispatch('toggleSidebar', false)
    }
}

router.beforeEach((to, from, next) => {
    store.commit('setLoading', true)
    next()
})

router.afterEach((to, from) => {
    mediaHandler()
    store.commit('setLoading', false)
})

/* eslint-disable no-new */
new Vue({
    el: '#app',
    router,
    store,
    template: '<App/>',
    components: { App }
})