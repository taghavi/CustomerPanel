import lazyLoading from './lazyLoading'

export default {
    name: 'Credit',
    meta: {
        expanded: false,
        title: 'menu.credit',
        iconClass: 'fa fa-google-wallet'
    },

    children: [{
            name: 'menu.addCredit',
            path: '/credit/add-credit',
            component: lazyLoading('credit/add-credit/AddCredit'),
            meta: {
                title: 'menu.addCredit'
            }
        },
        // {
        //     name: 'menu.creditReport',
        //     path: '/credit/credit-report',
        //     component: lazyLoading('credit/credit-report/CreditReport'),
        //     meta: {
        //         title: 'menu.creditReport'
        //     }
        // }
    ]
}