import lazyLoading from './lazyLoading'

export default {
  name: 'Reports',
  meta: {
    expanded: false,
    title: 'menu.reports',
    iconClass: 'vuestic-icon vuestic-icon-statistics'
  },

  children: [
    {
      name: 'menu.transactionreports',
      path: '/reports/transaction-reports',
      component: lazyLoading('reports/transaction-reports/TransactionReport'),
      meta: {
        title: 'menu.transactionReports'
      }
    },
    {
      name: 'menu.chargereports',
      path: '/reports/charge-reports',
      component: lazyLoading('reports/charge-reports/ChargeReport'),
      meta: {
        title: 'menu.chargeReports'
      }
    }
  ]
}
