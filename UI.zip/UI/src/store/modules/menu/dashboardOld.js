import lazyLoading from './lazyLoading'

export default {
  name: 'DashboardOld',
  path: '/dashboardOld',
  component: lazyLoading('dashboardOld/DashboardOld'),
  meta: {
    default: true,
    title: 'menu.dashboardold',
    iconClass: 'vuestic-icon vuestic-icon-dashboard'
  }
}
