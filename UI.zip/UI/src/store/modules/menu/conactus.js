import lazyLoading from './lazyLoading'

export default {
    name: 'ContactUs',
    path: '/contactus',
    component: lazyLoading('contactus/ContactUs'),
    meta: {
        title: 'menu.contactus',
        iconClass: 'fa fa-send'
    }
}