const state = {
    token: sessionStorage.getItem('token_id') || '',
    status: '',
    loginError: ''
}

const getters = {
    isAuthenticated: state => !!state.token,
    authStatus: state => state.status,
    hasLoginError: state => state.loginError
}

const mutations = {
    ['EMPTY_ERROR']: (state) => {
        state.loginError = ''
    },
    ['SET_ERROR']: (state, error) => {
        state.loginError = error
    },
    ['AUTH_REQUEST']: (state) => {
        state.status = 'loading'
    },
    ['AUTH_SUCCESS']: (state, resp) => {
        state.status = 'success'
        state.token = resp.access_token
        state.hasLoadedOnce = true
    },
    ['AUTH_ERROR']: (state) => {
        state.status = 'error'
        state.hasLoadedOnce = true
    },
    ['AUTH_LOGOUT']: (state) => {
        state.token = ''
    }
}

export default {
    state,
    getters,
    mutations
}