import utils from 'services/utils'

const state = {
    companyName: sessionStorage.getItem('company_name') || '',
    companyCredit: sessionStorage.getItem('credit') || ''
}

const getters = {
    companyName: state => state.companyName,
    companyCredit: state =>
        utils.formatMoney(utils.toPersianDigits(state.companyCredit), ""),
}

const mutations = {
    ['SET_NAME']: (state) => {
        state.companyName = sessionStorage.getItem('company_name') || '';
    },
    ['SET_CREDIT']: (state) => {
        state.companyCredit = sessionStorage.getItem('credit') || '';
    }
}

export default {
    state,
    getters,
    mutations
}