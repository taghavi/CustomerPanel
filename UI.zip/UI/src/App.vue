<template>
  <div id="app" class="app">
    <auth-layout v-if="isAuth"></auth-layout>
    <layout v-else></layout>
  </div>
</template>

<script>
  import Layout from 'components/layout/Layout'
  import AuthLayout from 'components/layout/AuthLayout'
  import VuesticPreLoader from 'vuestic-components/vuestic-preloader/VuesticPreLoader.vue'
  import LoginLayout from 'components/authentication/login-layout/LoginLayout.vue'
  import store from './store'

  export default {
    name: 'app',    
    components: {
      VuesticPreLoader,
      AuthLayout,	
      Layout,
      LoginLayout
    },
    // beforeMount(){
    //   if(!sessionStorage.getItem('token_id')){  
    //     this.$router.push({name: 'loginlayout'});
    //   }
    // },
    computed: {
      isAuth () {
      return this.$route.path.match('/authentication/login');  
      }
    }
  }
</script>

<style lang="scss">
  @import "sass/main";
  body {
    font-family: 'Yekan','Source Sans Pro'; 
    height: 100%;
    direction:rtl;
    #app {
      height: 100%;
    }
  }
</style>
