export default {
    irancell: [
        
    ]
}