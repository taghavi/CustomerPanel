export default {
    transResult: [{
            id: 0,
            description: 'تراکنش موفق'
        },
        {
            id: 1,
            description: 'تراکنش ناموفق'
        },
        {
            id: 2,
            description: 'تراکنش تکراری'
        },
        {
            id: 3,
            description: 'مبالغ ناهمخوانی دارند، مبلغ بازگشت داده شد'
        },
        {
            id: 4,
            description: 'خطای تأیید تراکنش'
        },
        {
            id: 5,
            description: 'خطای درگاه پرداخت'
        },
        {
            id: 6,
            description: 'خطا در ثبت نهایی'
        },
    ]
}