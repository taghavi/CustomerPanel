export default {
    transactionTypes: [{
            id: 5,
            description: 'پین'
        },
        {
            id: 0,
            description: 'تاپ آپ'
        },
        {
            id: -1,
            description: 'همه'
        }
    ],
    transactionStatus: [{
            id: 1,
            description: 'موفق'
        },
        {
            id: 0,
            description: 'ناموفق'
        },
        {
            id: 2,
            description: 'سایر'
        },
        {
            id: -1,
            description: 'همه'
        }
    ],
    mobileCellOperators: [{
            id: 2,
            description: 'ایرانسل'
        },
        {
            id: 3,
            description: 'رایتل'
        },
        {
            id: 1,
            description: 'همراه اول'
        },
        {
            id: -1,
            description: 'همه'
        }
    ],
    unit: [{
            id: 0,
            description: 'مالی'
        },
        {
            id: 1,
            description: 'فروش'
        },
        {
            id: 2,
            description: 'پشتیبانی'
        },
        {
            id: 3,
            description: 'سایر'
        }
    ],
    priority: [{
            id: 0,
            description: 'کم'
        },
        {
            id: 1,
            description: 'متوسط'
        },
        {
            id: 2,
            description: 'زیاد'
        }
    ],
    PGs: [{
        id: 1,
        description: 'مبنا کارت آریا'
    }],
}